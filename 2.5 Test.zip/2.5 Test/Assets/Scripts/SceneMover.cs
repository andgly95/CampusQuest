﻿using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using IsoTools.Physics;
using IsoTools;

//namespace IsoTools.Examples.Kenney{
public class SceneMover : MonoBehaviour {

	//SerializedField makes the private variable visible in the editor
	[SerializeField]private string loadLevel;
	private GameObject player;
		//new Vector3 prevRoomPlayerPos;
	IsoObject _isoObject = null;
	Transform _prevIsoWorld = null;


	//To use this script, attach it to the trigger collider that you want to be the passage 
	//between levels. 
	//Make sure the collider "Is Trigger" is checked.
	//Add Scenes to the file -> buildsettings
	// type in what scene the collider should take you to in the inspector
	void GetPlayer(){
		Transform[] ts = _prevIsoWorld.gameObject.GetComponentsInChildren<Transform> ();
		foreach (Transform t in ts)
			if (t.gameObject.CompareTag ("Player"))
				player = t.gameObject;
	}

	void OnEnable() {

		SceneManager.sceneLoaded += OnLevelFinishedLoading;
	}

	void OnLevelFinishedLoading(Scene scene, LoadSceneMode mode)
	{
		Debug.Log("Level Loaded");
		Debug.Log(scene.name);
		//Debug.Log(mode);

		// trying to set the active scene as the new room

	//	Debug.Log(SceneManager.SetActiveScene(SceneManager.GetSceneByName(loadLevel)));
		Debug.Log("Active scene is '" + scene.name + "'.");

		// logs the new room :)

		GameObject[] gObjs = SceneManager.GetActiveScene ().GetRootGameObjects ();
		Debug.Log (gObjs.Length);
		player = GameObject.FindGameObjectsWithTag ("Player")[0];
		Debug.Log (player);

		/*player.transform.parent = 
				Destroy (_prevIsoWorld);
				*/
	}	
		
	void OnDisable() {

		SceneManager.sceneLoaded -= OnLevelFinishedLoading;

	}

	void Start () {
		GameObject[] gObjs = SceneManager.GetActiveScene ().GetRootGameObjects ();
		foreach (GameObject g in gObjs)
			if (g.tag == "IsoWorld")
				_prevIsoWorld = g.GetComponent<Transform>();

		GetPlayer ();
		_isoObject = player.GetComponent<IsoObject> ();
	}
	void Update() {
		
	}

	void OnIsoTriggerEnter(IsoCollider other){
		//Debug.Log("IsoWent Through the door.");
		//prevRoomPlayerPos = (_isoObject.position);

		//Debug.Log ("Previous Room IsoObject Coordinates" + prevRoomPlayerPos);

		if (other.CompareTag ("Player")) {
			//Debug.Log ("IsoAnd now we transition");
			player.SendMessage("IsoWorldDelete");
			_prevIsoWorld = player.transform.parent;
			Debug.Log(_prevIsoWorld);
			SceneManager.LoadScene (loadLevel);




		}
	}
}


