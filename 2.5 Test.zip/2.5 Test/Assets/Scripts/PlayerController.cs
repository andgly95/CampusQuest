﻿using UnityEngine;
using IsoTools.Physics;

namespace IsoTools.Examples.Kenney {
	[RequireComponent(typeof(IsoRigidbody))]
	public class PlayerController : MonoBehaviour {
		
		public static PlayerController playerController;
		private IsoWorld _IsoWorld;
		public float speed = 2.0f;
		private bool isGrounded;

		IsoRigidbody _isoRigidbody = null;

		void IsoWorldInit(){
			if (_IsoWorld != null) {
				DontDestroyOnLoad (_IsoWorld);
				//DontDestroyOnLoad (player);
				//set the gameController to this instance of the GameController class
				playerController = this;
			} else if (playerController != this) {
				Destroy (_IsoWorld);
			} 

		}

		void IsoWorldDelete(){
			Transform[] children = _IsoWorld.GetComponentsInChildren<Transform> ();
			foreach (Transform t in children) {
				//Debug.Log (t.gameObject);
				if (!(t.gameObject.CompareTag ("Player") || t.gameObject.CompareTag ("PlayerSprite") || t.gameObject.CompareTag ("IsoWorld")))
					Destroy (t.gameObject);
			}
			//Debug.Log (children);
		}

		IsoWorld GetWorld(){
			return GetComponentInParent<IsoWorld>();
		}

		void Awake(){// Player Singleton Manager
			_IsoWorld = GetComponentInParent<IsoWorld>(); // maybe getcomponentofparent
			//Debug.Log(_IsoWorld);


			IsoWorldInit ();
		}

		void Start() {
			_isoRigidbody = GetComponent<IsoRigidbody>();
			if ( !_isoRigidbody ) {
				throw new UnityException("PlayerController. IsoRigidbody component not found!");
			}
		}

		void Update () {
			//isGrounded = IsoPhysics.Raycast(ray, out hit, groundCheckRadius, groundLayer, QueryTriggerInteraction.Collide);
			var velocity = _isoRigidbody.velocity;

			//Movement//
	
			velocity.x = 0;
			velocity.y = 0;

			if (Input.GetKey (KeyCode.LeftArrow)) {
				velocity.x += -0.8f*speed;
				velocity.y += 0.8f*speed;
			}
			if (Input.GetKey (KeyCode.RightArrow)) {
				velocity.x += 0.8f*speed;
				velocity.y += -0.8f*speed;
			}
			if (Input.GetKey (KeyCode.DownArrow)) {
				velocity.y += -0.8f*speed;
				velocity.x += -0.8f*speed;
			}
			if (Input.GetKey (KeyCode.UpArrow)) {
				velocity.y += 0.8f*speed;
				velocity.x += 0.8f*speed;
			}
			if (Input.GetButtonDown ("Jump") && isGrounded) {
				velocity.z += 1.5f*speed;
			}

			_isoRigidbody.velocity = velocity;
		}

		void OnIsoCollisionEnter(IsoCollision iso_collision) {
			if(iso_collision.gameObject.tag == "Floors"){
				isGrounded = true;
			}
		}

		void OnIsoCollisionExit(IsoCollision iso_collision) {
			if(iso_collision.gameObject.tag == "Floors"){
				isGrounded = false;
			}
		}
	}
}